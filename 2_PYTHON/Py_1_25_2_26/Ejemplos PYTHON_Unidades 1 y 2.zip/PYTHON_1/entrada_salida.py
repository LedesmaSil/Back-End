# lado=input("Ingresar el lado del cuadradao:")
lado=int(input("Ingresar el lado del cuadradao:"))
superficie=lado*lado
print("La superficie es "+ str(superficie))
print("La superficie es ", superficie)