# Comentario en línea
'''
Comentarios 
en
bloque
'''

#tipos de datos
cadena= "Hola Mundo en Python" #Strings
entero= 3 #int
flotante= 12.3 #float
logico= True # o False (con primer letra mayúscula) boolean

# variables
# cadena_string: Esta nomenclatura se utiliza para funciones
# cadenaString: La nomenclatura camelCase se usa para variables
cadenaString= "123"
valorNumerico= 123

#Operador de asignación
variable= 12 #Entero
variable= 12.3 #Asignamos otro valor de otro tipo (tipado dinámico)
variable= "Cadena" #No es aconsejable reutilizar la misma variable con otro tipo de dato
# Estas variables son globales de por sí