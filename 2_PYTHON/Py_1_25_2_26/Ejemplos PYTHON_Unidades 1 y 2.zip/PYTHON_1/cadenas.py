diaDeSemana="Lunes"
diaFinDeSemana='Domingo'

# mes=input("Ingrese el mes")

apellido="Martínez"
print(apellido[0])
if apellido[0]=="M":
    print(apellido)
    print("Comienza con M")

print(len(apellido)) # 8
print(apellido.lower()) #martínez
print(apellido.upper()) #MARTÍNEZ

nombre="carlos"
print(nombre.capitalize()) #Carlos

nombre= nombre.capitalize()
print(nombre, apellido) #Carlos Martínez

