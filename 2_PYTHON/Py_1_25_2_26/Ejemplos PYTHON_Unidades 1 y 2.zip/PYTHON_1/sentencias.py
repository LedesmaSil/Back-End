a=2+3 #una lìnea
print(a)
a= 2 + 3 + 4 + 5 \
    + 6 + 7 + 8 + \
    9 # sentencia dividida en lìneas
print(a) 

c= [2, 3, 4, 
    5, 6, 7, 8, 
        9, 10] # continuaciòn de lìnea implìcita
print (c) 