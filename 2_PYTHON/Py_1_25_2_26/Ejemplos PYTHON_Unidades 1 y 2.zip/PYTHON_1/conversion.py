# conversion
# str -> int
print(int("123")) #Si queremos convertir 123a da error
# int -> str
print(str(289)) #Si queremos sumar un valor numérico daría error
# str -> float
print(float("123.12"))
# int -> float
print(float(145)) #Agrega el 0
# float -> int
print(int(1373.12)) #Trunca el dato, conserva la parte entera, no es lo mismo que redondear