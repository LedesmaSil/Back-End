print(5 + 2) # Suma del número 5 y el número 2

a=5
print(a < 10) # Compara si el valor de la variable a es menor que 10

b=4
print(b is None) # Compara si la identidad de la variable b es None

b=None
print(b is None)

c=20
print(3 * (200 - c)) # Resta a 200 el valor de c y lo multiplica por 3
