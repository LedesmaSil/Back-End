import mis_funciones
mis_funciones.saludo("Luis")
mis_funciones.otra_funcion()