def saludo(nombre):
    print(f'Hola {nombre}')

def otra_funcion():
    print("Soy otra función")