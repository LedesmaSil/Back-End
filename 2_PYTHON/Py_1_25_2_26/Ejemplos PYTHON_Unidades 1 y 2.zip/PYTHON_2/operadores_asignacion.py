i=0
i= i+1
print(i)

# Operadores binarios
i+=1 #Incremento en 1 la variable i, equivamente a i= i+1. No tenemos el i++
print(i)
i-=1 #Decremento en 1 la variable i, equivalente a i= i-1. No tenemos el i++
i*=1
i/=1

# Sumatoria
suma= 0
num=  int(input())
suma+= num # Equivalente a suma= suma + num

