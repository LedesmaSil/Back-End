# verificaciones_numericas.py
def es_par(n):
    ''' Tarea: determina si el número es par '''
    if n%2 == 0:
        return True
    else:
        return False