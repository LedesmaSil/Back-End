# Excepciones: Otros ejemplos
def f(x, y):
     return x / y

def g(x, y):
    return f(x, y)

z = g(5, 0)