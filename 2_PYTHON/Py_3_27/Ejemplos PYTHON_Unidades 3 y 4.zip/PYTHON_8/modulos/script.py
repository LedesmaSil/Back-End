# import saludos

# saludos.saludar()
# from saludos import saludar

# saludar()

# from saludos import *

# saludar()

from saludos import Saludo

s = Saludo()