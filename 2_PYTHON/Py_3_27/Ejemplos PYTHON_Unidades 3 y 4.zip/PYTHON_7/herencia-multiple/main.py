from a import A
from b import B
from c import C

def main():
    c = C()
    c.a()
    c.b()
    c.c()

if __name__ == "__main__":
    main()