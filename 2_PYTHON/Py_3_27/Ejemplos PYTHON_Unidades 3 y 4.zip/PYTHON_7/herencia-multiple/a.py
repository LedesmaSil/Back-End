class A:
    
    def a(self):
        print("Este método lo heredo de A")

    def b(self):
        print("Este método también lo heredo de A")