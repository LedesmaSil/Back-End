class B:
    
    def b(self):
        print("Este método lo heredo de B")